# マイルーム 壁紙・床 イラスト生成プロンプト（テンプレート・改訂版）

一部の単語を書き換えるだけで、いろいろなバリエーションを作れるようにしたテンプレートです。
【　】で囲った部分だけ差し替えてください。

**前回のプロンプトの縦横比の説明に誤りがありました。** 実際のコードでは、画面の上62%が
壁紙、下38%が床になっており、スマホの縦長画面で計算すると、壁は横長ではなく
「やや縦長」、床は「横長というよりほぼ正方形（気持ち横長）」になります。今回のテンプレートは、
この正しい比率で作り直しています。

---

## 壁紙用テンプレート（縦横比 目安 3:4、縦長）

```
A simple, seamless-looking wall texture illustration for a cozy room background
in a warm colored-pencil / watercolor style, matching a cute Japanese
mochi-mascot game's art direction.

The image should be a tall-ish rectangle, roughly 3:4 in aspect ratio
(width:height), showing only a flat wall surface — no furniture, no
characters, no windows, no doors. Just the wall material itself, evenly
lit, with soft, subtle texture so it doesn't look like empty flat color
but still stays calm and uncluttered.

Wall style: 【例：淡いクリーム色のしっくい壁 / 小さな花柄の壁紙 / 木目調のパネル壁】
Mood: 【例：あたたかく、のどか / さわやかで清潔感がある / レトロでかわいい】

No text, no watermark, no characters, no shadows of objects. Soft, even
lighting throughout the entire image.
```

## 床用テンプレート（縦横比 目安 5:4、ほぼ正方形・気持ち横長）

```
A simple, seamless-looking floor texture illustration for a cozy room
background, in a warm colored-pencil / watercolor style, matching a cute
Japanese mochi-mascot game's art direction.

The image should be a rectangle close to square, roughly 5:4 in aspect
ratio (width:height, very slightly wider than tall), showing only a flat
floor surface viewed from a slightly elevated angle — no furniture, no
characters, no rugs. Just the floor material itself, evenly lit, with
soft, subtle texture so it doesn't look like empty flat color but still
stays calm and uncluttered.

Floor style: 【例：明るいフローリング / 畳 / 淡い水色のタイル】
Mood: 【例：あたたかく、のどか / さわやかで清潔感がある / レトロでかわいい】

No text, no watermark, no characters, no shadows of objects. Soft, even
lighting throughout the entire image.
```

---

## 使い方のコツ
- 「Wall style」「Floor style」の1行だけ書き換えれば、別の壁紙・床のバリエーションを量産できます
- 「Mood」も変えると、同じ素材でも雰囲気（春っぽい／和風／北欧風など）を調整できます
- あえて「家具や人物を描かない」よう指定しているのは、後で家具を別レイヤーとして重ねる仕組みになっているためです
- 実際の表示は `object-fit:cover` で画面いっぱいに引き伸ばし・クロップされるので、上記の比率から多少ズレても大きな問題にはなりませんが、目安として伝えておくと、極端に違う形（すごく横長・すごく縦長）で生成されるのを防げます
